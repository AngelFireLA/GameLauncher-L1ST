import interface.menu_principal as menu_principal

menu_principal.main()
