class Joueur:

    def __init__(self, nom, couleur):
        self.nom = nom
        self.couleur = couleur
