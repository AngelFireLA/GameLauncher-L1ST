class Joueur:

    def __init__(self, nom, symbole):
        self.nom = nom
        self.symbole = symbole
